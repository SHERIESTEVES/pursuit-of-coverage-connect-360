CalAIM Connect360 Website

Files included:
- index.html
- styles.css
- script.js

How to use:
1. Open index.html in any browser to preview.
2. Upload all three files to a website host such as Wix custom embed, WordPress, Squarespace developer mode, Netlify, Vercel, GitHub Pages, or a standard web server.
3. Replace the placeholder brand name, contact form behavior, and demo submission handling as needed.

Website sections:
- Hero landing section
- Platform overview
- Core modules
- Referral-to-reimbursement workflow
- Collaborators
- EHR education/classes
- Reporting dashboards
- Security and compliance
- Demo request form
